# Channel-Cloning

A multi-user Telegram assistant bot. Users chat with one bot (created via
[@BotFather](https://t.me/BotFather)) and log in with their **own** Telegram
account using `/login`. The bot then works on each user's behalf to:

- **Copy** all content (videos, photos, files, text) from one channel to another,
  with optional extras:
  - **Replace words** in captions/text and/or file names.
  - **Replace links** — rewrite the hidden URL inside hyperlinks (e.g.
    `t.me/oldchannel` → `t.me/newchannel`).
  - **Custom thumbnail** — upload a photo to use as the thumbnail for copied
    videos/documents.
  - **Caption / promo link** — add extra text (and a clickable promo link) to
    every caption, appended or prepended.
  - **Live speed** — `/status` shows transfer speed and messages/min with a
    progress bar and ETA.
- **Create** several private channels with the same name in one go.

Earlier versions needed a single `SESSION_STRING` so only the owner could use the
bot. This version removes that: anyone can log in and use it with their own account.

## Setup

1. Get `API_ID` and `API_HASH` from [my.telegram.org](https://my.telegram.org).
2. Create a bot with [@BotFather](https://t.me/BotFather) and get its `BOT_TOKEN`.
3. Set the environment variables and run the worker.

### Environment variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `API_ID` | yes | — | From my.telegram.org (used to log in every user) |
| `API_HASH` | yes | — | From my.telegram.org |
| `BOT_TOKEN` | yes | — | From @BotFather |
| `RESTRICT` | no | `1` | Created channels block forwarding |
| `MAX_COUNT` | no | `50` | Max channels per `/create` |
| `CREATE_DELAY` | no | `3` | Seconds between created channels |
| `DELAY` | no | `1.5` | Seconds between copied messages |
| `EDIT_EVERY` | no | `4` | Seconds between live status updates |
| `SESSIONS_FILE` | no | `sessions.json` | Where logged-in sessions are stored |
| `THUMB_DIR` | no | `thumbs` | Folder for per-user custom thumbnails |
| `DOWNLOAD_DIR` | no | `./dl_tmp` | Where big files are downloaded temporarily. Keep it on large storage, not `/tmp` |
| `USE_FAST` | no | `1` | Parallel multi-connection **upload** (fast uploads). Set `0` to disable |
| `USE_FAST_DL` | no | `1` | Parallel **download** via FastTelethon. Set `0` for plain download |
| `PIPELINE` | no | `0` | `1` = overlap download+upload (~2x, more connections). `0` = one at a time (stable) |
| `FAST_UPLOAD_MB` | no | `5` | When `USE_FAST=1`, files larger than this use parallel transfer |
| `FT_CONNECTIONS` | no | `8` | Parallel connections per transfer (lower = more stable on small hosts) |
| `FLOOD_PENALTY_MAX` | no | `30` | Max extra seconds the adaptive flood protection may add to the message delay |
| `FLOOD_RECOVER` | no | `120` | Seconds of flood-free copying after which the adaptive penalty is halved |
| `FLOOD_NOTIFY_MIN` | no | `10` | Minimum flood-wait length (seconds) that triggers a chat notification. `0` = notify on every wait |
| `STALL_SECS` | no | `150` | If a download/upload makes no progress for this long, reconnect and retry the file (stall watchdog). `0` disables it |
| `STALL_RETRIES` | no | `3` | How many times to retry a stalled file before skipping it |
| `PROGRESS_FILE` | no | `progress.json` | Per-user copy progress |
| `SETTINGS_FILE` | no | `settings.json` | Per-user saved settings |

`SESSION_STRING` is no longer used.

### Run

```bash
pip install -r requirements.txt
python bot.py
```

Then open your bot in Telegram, press **Start**, and send `/login`.

## Logging in

1. Send `/login`.
2. Send your phone number in international format, e.g. `+919876543210`.
3. Enter the login code Telegram sends you. **Type it with spaces or dashes
   between the digits** (e.g. `1 2 3 4 5`) so Telegram doesn't block the code.
4. If you use two-step verification, enter your password.

Logging in lets the bot act on your behalf, so only use a bot you trust.

## Commands

`/login`, `/logout`, `/copy`, `/create`, `/status`, `/errors`, `/stop`,
`/ping`, `/about`, `/help`.

Shortcuts: `/copy <source> <destination> [message id]` and `/create <name> <number>`.

## Flood protection (adaptive pacing)

Telegram escalates its "flood wait" pauses: if an account keeps sending at the
same rate after a small pause, the pauses grow and can eventually become a
multi-hour wait (for example ~22000 s on a long job). The bot now reacts to every
flood wait: each one temporarily raises the delay between messages, and the extra
delay decays on its own once the waits stop. Your normal speed is unchanged — the
slowdown only kicks in when Telegram actually complains, which keeps the account
below the threshold that triggers the long punitive waits. `/status` shows the
current flood-safe pace. Tune it with `FLOOD_PENALTY_MAX` and `FLOOD_RECOVER`.

If a flood wait does happen, the bot sends you a message — e.g. `⏳ Telegram flood
wait — resuming in 6h 6m (22000s)…` — waits out the full time, and then resumes the
copy automatically from the exact message it paused on (nothing is skipped or
re-copied). Short waits below `FLOOD_NOTIFY_MIN` are handled silently so they don't
spam your chat.

## Stall watchdog (no more freezing on one file)

Large files are downloaded then re-uploaded, and occasionally a connection dies
mid-transfer without raising an error, which used to freeze the whole copy on that
one file. The bot now watches the transfer's byte counter: if it makes no progress
for `STALL_SECS` seconds, the bot tears the connection down, reconnects, and retries
the same file (up to `STALL_RETRIES` times). If it still cannot move the file it is
marked failed, listed in `/errors`, and the copy continues; you can resume later to
pick those up. For big-file jobs, `PIPELINE=0` (the default, one transfer at a time)
is the most reliable; `PIPELINE=1` is faster but keeps more connections open.

## Topic (forum) groups

When the source is a **topic group** (a forum), the guided `/copy` flow changes
after you choose the source and destination:

1. The bot detects the forum and shows the **list of topics** (search by typing
   part of a name). Topics that can be **resumed** are listed at the top.
2. **Pick one topic** to copy just that topic, or pick **“All topics”** to go
   through every topic and be asked Copy / Skip / Stop for each one while running.
3. If you picked a single topic, you then choose its **starting point** — from the
   beginning, a **Resume (after message ID …)** button, or a message ID you type.
4. Then the normal extras (replace words/links, thumbnail, caption) and Start.

When a topic is copied, its **title is posted first**, then its content. `/status`
shows progress **for the current topic** (e.g. `This topic: 2 / 5`) plus the overall
copied count. Re-running the same source → destination resumes each topic where it
left off (the title is not re-posted and nothing is re-copied). A normal channel is
copied exactly as before — the topic flow only applies to forum groups.

## Privacy note

Logged-in session strings are stored in `SESSIONS_FILE`. A session string grants
full access to that account, so keep the file private and use persistent storage
on your host so users stay logged in across restarts.
